% Facts
parent(tom, bob).
parent(tom, linda).
parent(pam, bob).
parent(pam, linda).
parent(bob, ann).
parent(bob, pat).
parent(pat, jim).

male(tom).
male(bob).
male(jim).

female(pam).
female(linda).
female(ann).
female(pat).

% Rules
mother(M, P) :-
    parent(M, P),
    female(M).

father(F, P) :-
    parent(F, P),
    male(F).

sibling(X, Y) :-
    parent(P, X),
    parent(P, Y),
    X \= Y.

grandparent(GP, GC) :-
    parent(GP, P),
    parent(P, GC).

sister(Sis, Person) :-
    female(Sis),
    sibling(Sis, Person).

brother(Bro, Person) :-
    male(Bro),
    sibling(Bro, Person).

% Additional rules for uncle/aunt
uncle(Uncle, Person) :-
    parent(P, Person),
    brother(Uncle, P).

aunt(Aunt, Person) :-
    parent(P, Person),
    sister(Aunt, P).

# ?- consult('family_tree.pl').

# % Query examples
# ?- mother(M, linda).
# % This will return M = pam.

# ?- sibling(bob, linda).
# % This will return true.

# ?- grandparent(GP, ann).
# % This will return GP = tom.

# ?- uncle(Uncle, jim).
# % This will return Uncle = bob.
