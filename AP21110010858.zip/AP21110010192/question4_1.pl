% Facts
student_info('John', 101, 'Math', 100, 85).
student_info('Alice', 102, 'Science', 100, 78).
student_info('Eva', 103, 'History', 100, 92).
student_info('Mike', 104, 'English', 100, 64).
student_info('Sophia', 105, 'Art', 100, 75).
student_info('Daniel', 106, 'Physics', 100, 88).

% Rules
compute_percentage(Student, Percentage) :-
    student_info(Student, _, _, MaxMarks, Obtained),
    Percentage is (Obtained / MaxMarks) * 100.

display_result(Student) :-
    student_info(Student, Roll, Subject, MaxMarks, Obtained),
    compute_percentage(Student, Percentage),
    format('Student: ~w~nRoll No: ~w~nSubject: ~w~nMax Marks: ~w~nObtained Marks: ~w~nPercentage: ~2f%', [Student, Roll, Subject, MaxMarks, Obtained, Percentage]).

% Usage
display_result('John').
