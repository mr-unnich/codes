union([], Set, Set).
union([H|T], Set, Result) :-
    member(H, Set),
    union(T, Set, Result).
union([H|T], Set, [H|Result]) :-
    \+ member(H, Set),
    union(T, Set, Result).

intersection([], _, []).
intersection([H|T], Set, [H|Result]) :-
    member(H, Set),
    intersection(T, Set, Result).
intersection([_|T], Set, Result) :-
    intersection(T, Set, Result).

complement([], _, []).
complement([H|T], Set, [H|Result]) :-
    \+ member(H, Set),
    complement(T, Set, Result).
complement([_|T], Set, Result) :-
    complement(T, Set, Result).

# ?- consult('set_operations.pl').

# ?- union([1, 2, 3], [3, 4, 5], Result).
# % This will give Result = [1, 2, 3, 4, 5].

# ?- intersection([1, 2, 3], [3, 4, 5], Result).
# % This will give Result = [3].

# ?- complement([1, 2, 3], [3, 4, 5], Result).
# % This will give Result = [1, 2].
